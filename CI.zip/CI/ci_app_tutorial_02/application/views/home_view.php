<div class="container">
    <blockquote>
        <h1>Create a simple website using Codeigniter</h1>
        <cite><a href="https://www.facebook.com/TryCatchClasses/">By TryCatch
                classes</a></cite>
    </blockquote>
    <div class="col-md-12 column">
        <h2>
            Heading
        </h2>
        <p>
            Donec id elit non mi porta gravida at eget metus. Fusce dapibus,
            tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum
            massa justo sit amet risus. Etiam porta sem malesuada magna mollis
            euismod. Donec sed odio dui.
        </p>
        <p>
            <a class="btn"
               href="https://www.facebook.com/TryCatchClasses/">View details »</a>
        </p>
    </div>
</div>
</body>
</html>