-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 23/10/2018 às 14:34
-- Versão do servidor: 5.7.21-0ubuntu0.16.04.1
-- Versão do PHP: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `crud_db_02`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `book_isbn` int(11) NOT NULL,
  `book_title` varchar(50) NOT NULL,
  `book_author` varchar(50) NOT NULL,
  `book_category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `books`
--

INSERT INTO `books` (`book_id`, `book_isbn`, `book_title`, `book_author`, `book_category`) VALUES
(1, 7893, 'Laravel Tiger', 'Mutafaf', 'Programming'),
(2, 8934, 'Android Programming', 'Farrukh', 'Programming'),
(3, 8902, 'Intro to Psychology', 'Ayesha', 'Psychology'),
(4, 2345, 'Calculus-1', 'John Doe', 'Math'),
(5, 8927, 'Chemistry Part-1', 'Aliza Mam', 'Chemistry'),
(6, 6723, 'Math Part-1', 'Sir Sohail Amanat', 'Math'),
(7, 7896, 'Javascript for begginners', 'Shami ', 'Programming'),
(8, 8978, 'iOS App ', 'Ehtesham Mehmood', 'Mobile Programming'),
(9, 8987, 'Physics', 'Sir Waqas', 'Physics'),
(10, 7890, 'HTML for dummies', 'Ehtesham Shami', 'Programming'),
(11, 1234, 'CodeIgniter Framework Introduction', 'Mutafaf', 'Programming');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
